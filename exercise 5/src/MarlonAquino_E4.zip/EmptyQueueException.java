public class EmptyQueueException extends RuntimeException{
}