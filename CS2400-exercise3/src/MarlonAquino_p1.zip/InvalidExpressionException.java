public class InvalidExpressionException extends RuntimeException{

}